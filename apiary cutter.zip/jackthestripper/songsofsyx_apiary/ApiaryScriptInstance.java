package jackthestripper.songsofsyx_apiary;


import java.io.IOException;


import script.SCRIPT.SCRIPT_INSTANCE;
import snake2d.util.file.FileGetter;
import snake2d.util.file.FilePutter;

public class ApiaryScriptInstance implements SCRIPT_INSTANCE{

	//private boolean hasMess;
	
	public ApiaryScriptInstance() {
		
	}
	
	@Override
	public void load(FileGetter f) throws IOException {
		// TODO Auto-generated method stub
		
	}
	
	
	@Override
	public void save(FilePutter f) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(double arg0) {
		//System.out.println("apiary script test");
				
	}

}
